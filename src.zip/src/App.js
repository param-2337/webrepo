import './App.css';
import React, { Component } from 'react';
import { Navbar, Nav, Form, FormControl, Button, Carousel, Container, Col, Row, Card } from 'react-bootstrap';
import Typedtxt from './Components/Typedtxt';
import BigCard from './Components/BigCard';
import SmallCard from './Components/SmallCard';
import Footer from './Components/Footer';
import About from './Components/About';
import Navibar from './Components/Navibar';
import Carousal from './Components/Carousal'
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import MainPage from './Components/MainPage';
import Countries from './Components/Countries';

class App extends Component {

  render() {
    return (
      <div>
        <Router>
          <Navibar />

          <Switch>
            <Route exact path="/about">
              <About />
            </Route>
            <Route exact path="/countries">
              <Carousal />
              <Countries />
            </Route>
            <Route exact path="/">
              <Carousal />
              <div className="my-1 mx-4">
                <h3>Domestic and International Packages</h3>
                <br />
              </div>
              <MainPage />
              <Footer />
            </Route>
          </Switch>
        </Router>
      </div>
    );
  }

}



export default App;
