import React,{Accordion} from 'react';

export default function About() {
    return (
        <div className="mx-5">
            <div className="my-4">
                <h1>About Us </h1>
            </div>
            <h5>
                <strong>Know about Tour India</strong>
            </h5>
            <p>
                Booking a travel package when it comes to travelling to new parts of the country or the world is a practice that has slowly gained a lot of popularity. Today, whenever it is about planning a holiday trip, many people have a preferred travel portal in India that is best for their specific needs. Owing to the faith bestowed in our travel services by our patrons, Tour India has established its niche and is counted among the top 10 travel agencies in India.

                We at Tour India understand that nowadays, travelling has become much more than just visiting a new destination. That is why each of our vacation packages offers you the respite that you anticipate from a holiday. As a well-informed traveller, it is only right to expect more from your travel company in India - we strive to ensure the same for our customers. It is no longer about only conveyance and accommodation. For those who enjoy travelling, the best travel packages are those which can offer them holistic holiday experiences. That is exactly what you get when you opt for the best travel company in India – Tour India.

                Counted among the top 10 travel agencies in India, Tour India has all the travel services under one roof. In our constant endeavour to be the best travel company in India, everything that we do is based on creating and setting new benchmarks. With extensive travel know-how, end-to-end travel planning and a wide assortment of travel packages, we are counted among the best travel agents in India that ensure the best holiday experiences.
            </p>
            <br />
            <h5><strong>Something more about us. :)</strong></h5>
            <Accordion>
                <Accordion.Item eventKey="0">
                    <Accordion.Header>Accordion Item #1</Accordion.Header>
                    <Accordion.Body>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                        veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                        commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
                        velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                        cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id
                        est laborum.
                    </Accordion.Body>
                </Accordion.Item>
                <Accordion.Item eventKey="1">
                    <Accordion.Header>Accordion Item #2</Accordion.Header>
                    <Accordion.Body>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                        veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
                        commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
                        velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                        cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id
                        est laborum.
                    </Accordion.Body>
                </Accordion.Item>
            </Accordion>
        </div>
    )
}
