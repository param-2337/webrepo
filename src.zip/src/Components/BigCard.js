import React from 'react'
import { Component } from 'react';
import '../CSS/BigCard.css';
import { Link, NavLink } from 'react-router-dom';

class BigCard extends Component {
    render() {
        return (
            <div className="card2">
                <div className="card2-img"
                    style={{ "backgroundImage": "url(https://images.unsplash.com/photo-1491374812364-00028bbe7d2f?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=a22e4862c36c552e726815949fbcb41a&auto=format&fit=crop&w=500&q=60)" }}>
                    <div className="overlay">
                        <div className="overlay-content">
                            <Link to="/countries">View Packages</Link>
                        </div>
                    </div>
                </div>
                <div className="card2-content">
                    <a href="#!">
                        <h2><strong>International Tours</strong></h2>
                        <p>Explore the World with Tur India</p>
                    </a>
                </div>
            </div>
        )
    }
}

export default BigCard;