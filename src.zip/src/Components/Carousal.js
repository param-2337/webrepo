import React from 'react'
import { Carousel  } from 'react-bootstrap';
import Typedtxt from './Typedtxt';

export default function Carousal() {
    return (
        <div>
             <Carousel fade>
                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    src="https://source.unsplash.com/1600x400/?india"
                    alt="First slide"
                  />
                  <Carousel.Caption>
                    <h3 className="App-typed-text">
                      <Typedtxt />
                    </h3>
                    <p>Visit the best places.
                      <br />
                      Every nook and corner explored.</p>
                  </Carousel.Caption>
                </Carousel.Item>
                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    src="https://source.unsplash.com/1600x400/?ni"
                    alt="Second slide"
                  />

                  <Carousel.Caption>
                    <h3 className="App-typed-text">
                      <Typedtxt />
                    </h3>
                    <p>Visit the best places.
                      <br />
                      Every nook and corner explored.</p>
                  </Carousel.Caption>
                </Carousel.Item>
                <Carousel.Item>
                  <img
                    className="d-block w-100"
                    src="https://source.unsplash.com/1600x400/?rain"
                    alt="Third slide"
                  />

                  <Carousel.Caption>
                    <h3 className="App-typed-text">
                      <Typedtxt />
                    </h3>
                    <p>Visit the best places.
                      <br />
                      Every nook and corner explored.</p>
                  </Carousel.Caption>
                </Carousel.Item>
              </Carousel>

        </div>
    )
}
