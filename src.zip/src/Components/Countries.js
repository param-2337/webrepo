import React from 'react'
import SmallCard from './SmallCard';
import { Navbar, Nav, Form, FormControl, Button, Carousel, Container, Col, Row, Card, Breadcrumb } from 'react-bootstrap';


export default function Countries() {
    return (
        <>
            <Breadcrumb>
                <Breadcrumb.Item href="#">Home</Breadcrumb.Item>
                <Breadcrumb.Item href="https://getbootstrap.com/docs/4.0/components/breadcrumb/">
                    Library
                </Breadcrumb.Item>
                <Breadcrumb.Item active>Data</Breadcrumb.Item>
            </Breadcrumb>
            <Container fluid>
                <Row>
                    <Col md={4}>
                        <div className="mx-5 my-3">
                            <h2>International Tour Packages</h2>
                            <p style={{ "font-family": "century gothic" }}>The unpredictable charms spread across the foreign lands, are waiting to be known, waiting to be experienced!</p>
                        </div>
                    </Col>
                    <Col md={8}>
                        <div className="my-3">
                            <p style={{ "font-family": "calibri", "font-size": 16 }}>We strive to best serve the traveler's interests and offer perfect getaways to discover the world’s alluring scenic beauty. Our international tour packages are supervised by professional tour managers who bring new life to each tour. Whatever you crave for, may it be a Desert Safari in Dubai, or Parasailing in Thailand, or being at the Top of Europe (Jungfrau, Switzerland), we have it all! Exploring the world along with your special one can bring a whole new life to your tour with our international honeymoon packages. We empower you to make the most fascinating memories with us and relish our legacy to travel, explore and celebrate life.</p>
                            <p style={{ "font-family": "calibri", "font-size": 14 }}>Pinning the world map to the wall and choosing a destination on the blindfolded shot of a dart, was an aspiration of the era that lived decades ago. However hard it was in those times, we’ve reached a stage now, where making that ambition come true is absolutely possible. Making the world accessible, we at Tour India as pioneers of innovative domestic and international holiday packages aim to deliver exceptional travel experiences for you. With ideal perceptions, we help you choose intricately designed best tour packages that are available with us. </p>
                        </div>
                    </Col>
                </Row>
                <div className="mx-3"> <hr color="black" /></div>
            </Container>
            <Container fluid>
                <br />
                <Row >
                    <Col xs={12} md={9}>
                        <Container fluid>
                            <Row align="center">
                                <Col><SmallCard /></Col>
                                <Col><SmallCard /></Col>
                                <Col><SmallCard /></Col>
                            </Row>
                            <Row align="center">
                                <Col><SmallCard /></Col>
                                <Col><SmallCard /></Col>
                                <Col><SmallCard /></Col>
                            </Row>
                            <Row align="center">
                                <Col><SmallCard /></Col>
                                <Col><SmallCard /></Col>
                                <Col><SmallCard /></Col>
                            </Row>
                        </Container>
                    </Col>
                    <Col xs={6} md={3} align="center">
                        <Card style={{ width: '18rem' }}>
                            <Card.Img variant="top" src="holder.js/100px180" />
                            <Card.Body>
                                <Card.Title>Card Title</Card.Title>
                                <Card.Text>
                                    Some quick example text to build on the card title and make up the bulk of
                                    the card's content.
                                </Card.Text>
                                <Button variant="primary">Go somewhere</Button>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </>
    )
}
