import React from 'react'
import BigCard from './BigCard';
import SmallCard from './SmallCard';
import { Navbar, Nav, Form, FormControl, Button, Carousel, Container, Col, Row, Card } from 'react-bootstrap';
import { Link, NavLink } from 'react-router-dom';

export default function MainPage() {
    return (
        <>
            <Container fluid>
                <Row >
                    <Col xs={12} md={9}>
                        <Container fluid>
                            <Row align="center">
                                <Col><BigCard /></Col>
                                <Col><BigCard /></Col>
                            </Row>
                            <Row align="center">
                                <Col><SmallCard /></Col>
                                <Col><SmallCard /></Col>
                                <Col><SmallCard /></Col>
                            </Row>
                            <Row align="center">
                                <Col><SmallCard /></Col>
                                <Col><SmallCard /></Col>
                                <Col><SmallCard /></Col>
                            </Row>
                        </Container>
                    </Col>
                    <Col xs={6} md={3} align="center">
                        <Card style={{ width: '18rem' }}>
                            <Card.Img variant="top" src="holder.js/100px180" />
                            <Card.Body>
                                <Card.Title>Card Title</Card.Title>
                                <Card.Text>
                                    Some quick example text to build on the card title and make up the bulk of
                                    the card's content.
                                </Card.Text>
                                <Button variant="primary">Go somewhere</Button>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </Container>
        </>
    )
}
