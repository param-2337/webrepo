import React, { Component } from 'react';
import '../CSS/SmallCard.css';

class SmallCard extends Component {
    render() {
        return (
            <div className="card3">
                <div className="card3-img"
                    style={{ "backgroundImage": "url(https://images.unsplash.com/photo-1519176336903-04be58a477d2?ixlib=rb-0.3.5&ixid=eyJhcHBfaWQiOjEyMDd9&s=eda05ddcb3154f39fd8ce88fdd44f531&auto=format&fit=crop&w=500&q=60)" }}>
                    <div className="overlay">
                        <div className="overlay-content">
                            <a href="#!">View Project</a>
                        </div>
                    </div>
                </div>
                <div className="card3-content">
                    <a href="#!">
                        <h2>Title</h2>
                        <p>Lorem ipsum dolor sit amet consectetur, lorem ipsum dolor</p>
                    </a>
                </div>
            </div>
        )
    }
}


export default SmallCard;
