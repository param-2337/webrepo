import React from 'react';
import Typewriter from 'typewriter-effect';

export default function Typedtxt() {
    return (
        <div>
            <Typewriter
                options={{
                    autoStart: true,
                    loop: true,
                    delay: 40,
                    strings: [
                        "Tour India welcomes you.", "Find best places.", "Don`t forget to check new Varsha Sahal", "Happy holidays!"
                    ],
                    pauseFor: 800

                }}
            /*
            onInit={(typewriter) => {

                typewriter.typeString("GeeksForGeeks")
                    .pauseFor(1000)
                    .deleteAll()
                    .typeString("Welcomes You")
                    .start();
            }}
            */
            />
        </div>
    )
}
